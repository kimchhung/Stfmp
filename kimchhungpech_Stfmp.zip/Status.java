
public class Status {
	public static final String OK = "ok";
	public static final String NOT_FOUND = "not_found";
	public static final String INVALID = "invalid";
}
