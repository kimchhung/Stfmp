
public class Action {

	public static final String WRITE = "write";
	public static final String VIEW = "view";
	public static final String CLOSE = "close";

}
